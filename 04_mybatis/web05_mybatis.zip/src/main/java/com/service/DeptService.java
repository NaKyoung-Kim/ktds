package com.service;

import java.util.List;

import com.dto.DeptDTO;

public interface DeptService {

	//구현해야 되는 작업을 추상 메서드로...
	public List<DeptDTO> list() throws Exception;
}
