package com.service;

import java.util.List;

import org.apache.ibatis.session.SqlSession;

import com.config.MySQLSessionFactory;
import com.dao.DeptDAO;
import com.dto.DeptDTO;

public class DeptServiceImpl implements DeptService {
	/*
	 SqlSession session = MySQLSessionFactory.getSession();
		try {
		
		}finally {
			session.close();			
		} 
	 */
	@Override
	public List<DeptDTO> list() throws Exception {
		List<DeptDTO> list = null;
		SqlSession session = MySQLSessionFactory.getSession();
		try {
			DeptDAO dao = new DeptDAO();
			list = dao.list(session);
		}finally {
			session.close();			
		}
		return list;
	}

	@Override
	public int write(DeptDTO dto) throws Exception {
		SqlSession session = MySQLSessionFactory.getSession();
		int n = 0;
		try {
			DeptDAO dao = new DeptDAO();
			n = dao.write(session, dto);
			session.commit(); // 명시적으로 commit 지정
		}finally {
			session.close();			
		} 
		return n;
	}

}
