package com.service;

import java.util.List;

import org.apache.ibatis.session.SqlSession;

import com.config.MySQLSessionFactory;
import com.dao.DeptDAO;
import com.dto.DeptDTO;

public class DeptServiceImpl implements DeptService {
	/*
	 SqlSession session = MySQLSessionFactory.getSession();
		try {
		
		}finally {
			session.close();			
		} 
	 */
	@Override
	public List<DeptDTO> list() throws Exception {
		List<DeptDTO> list = null;
		SqlSession session = MySQLSessionFactory.getSession();
		try {
			DeptDAO dao = new DeptDAO();
			list = dao.list(session);
		}finally {
			session.close();			
		}
		return list;
	}

}
