package com.dao;

import java.util.List;

import org.apache.ibatis.session.SqlSession;

import com.dto.DeptDTO;

public class DeptDAO {
	
	public List<DeptDTO> list(SqlSession session) throws Exception {
	
		// 1. 하나의 행
//	DeptDTO dto  = session.selectOne("mapper id");
//	DeptDTO dto	 = session.selectOne("mapper id", 값);
		// 2. 다중 행
//	List<DeptDTO> list = session.selectList("mapper id");
//	List<DeptDTO> list = session.selectList("mapper id", 값);
//	List<DeptDTO> list = session.selectList("mapper id", 값, RowBounds);
		
		List<DeptDTO> list = session.selectList("com.config.DeptMapper.deptAll");
		return list;
	}
	public int write(SqlSession session, DeptDTO dto) throws Exception {
		  int n =  session.insert("com.config.DeptMapper.write", dto);
		  return n;
	}
}





