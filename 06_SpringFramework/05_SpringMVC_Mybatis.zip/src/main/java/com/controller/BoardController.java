package com.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.dto.BoardDTO;
import com.service.BoardService;

@Controller
public class BoardController {

	@Autowired
	BoardService service;
	
	@RequestMapping("/list")
	public ModelAndView list() throws Exception{
		//모델
		List<BoardDTO> list = service.list();
		
		ModelAndView mav = new ModelAndView();
		mav.addObject("boardList", list);
		mav.setViewName("list");   // /WEB-INF/views/list.jsp
		
		return mav;
	}
	
//	@GetMapping("/writeForm")
	@RequestMapping(value = "/writeForm", method = RequestMethod.GET)
    public String writeForm()throws Exception{
    	return "write"; // /WEB-INF/views/write.jsp
    }
	
	@RequestMapping(value = "/write", method = RequestMethod.POST)
	public String write(BoardDTO dto) throws Exception{
		int n = service.write(dto);
//		return "list";  // /WEB-INF/views/list.jsp
		return "redirect:list";   // @RequestMapping("/list") 요청됨
	}
	
	
	
	
}
